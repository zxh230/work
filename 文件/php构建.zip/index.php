<?php
try {
    $link = mysqli_connect('172.86.86.5','root','123.com');
    if($link) {
        echo "非常开心, 数据库连接成功!!!\n";
    } else {
        echo "恭喜恭喜, 数据库连接失败~~~\n";
    }
} catch (mysqli_sql_exception $e) {
    echo "恭喜恭喜, 数据库连接失败~~~\n";
    // 如果你想看到具体的错误信息，可以取消下面这行的注释
    // echo "错误信息: " . $e->getMessage() . "\n";
}
?>