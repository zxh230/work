前提:
	1) 所有节点之间, 相互之间免密认证
	2) 所有节点yum源配置正常
	3) gw服务器有相关的安装包
	4) 系统时间要正确
	5) 二选一: 所有节点 /etc/hosts 要统一 或 通过dns解析来实现
	6) 主机名 要符合规范

环境拓扑: (初始快照)  1G内存可以完成实验
node01  10.15.200.101  Primary_Master   ServerID=101  主(读写)
node02  10.15.200.102  Candidate_Master ServerID=102  从(读)
node03  10.15.200.103  slave01          ServerID=103  从(读)
node04  10.15.200.104  slave02          ServerID=104  从(读)     # 此实验无4节点
node05  10.15.200.105  mha              ServerID=105  高可用监控

node01为主服务器 node02为从服务器 node03为从服务器
当主服务器:node01故障时 node02由从提升为主 node03将主服务器重新指向node02(原为node01)

# 1. 所有节点(node01 node02 node03 node05) 还原快照 (配置一个仓库: mha.repo)

# 2. 在node01 node02 node03 安装 mariadb
yum install mariadb-server -y

# 数据库配置文件已经提供 分别复制到对应 主机: /etc/my.cnf
node01 node02 node03 执行如下命令:

# 3. 在所有节点 安装MHA (node01 node02 node03 node05)    # 前提
yum install mha4mysql-node-0.58 -y

主节点: node01 安装数据库 启动服务  配置用户名和密码
[root@node01 ~]# systemctl start mariadb
# 修改root密码 创建用户复制用户repl及mha管理用户mha   (密码必须一样)
mysql>
ALTER USER 'root'@'localhost' IDENTIFIED BY '!@#qweASD69';
grant replication slave on *.*  to repl@'10.15.200.%' identified by '!@#qweASD69';
grant all on *.* to mha@'10.15.200.%' identified by '!@#qweASD69';
flush privileges;

MariaDB [(none)]> show master status\G;
*************************** 1. row ***************************
            File: bin-log.000002
        Position: 1011
    Binlog_Do_DB:
Binlog_Ignore_DB:

node02: 同理类似
mysql>
ALTER USER 'root'@'localhost' IDENTIFIED BY '!@#qweASD69';
grant replication slave on *.*  to repl@'10.15.200.%' identified by '!@#qweASD69';
grant all on *.* to mha@'10.15.200.%' identified by '!@#qweASD69';
flush privileges;

接着 在node02上配置从服务器 执行如下命令:
mysql>
CHANGE MASTER TO
MASTER_HOST='10.15.200.101',
MASTER_PORT=3306,
MASTER_LOG_FILE='bin-log.000002',
MASTER_LOG_POS=997,
MASTER_USER='repl',
MASTER_PASSWORD='!@#qweASD69';

mysql> show slave status\G;
             Slave_IO_Running: No
            Slave_SQL_Running: No

mysql> start slave;

mysql> show slave status\G;
*************************** 1. row ***************************
               Slave_IO_State: Waiting for master to send event
                  Master_Host: 10.15.200.101
                  Master_User: repl
                  Master_Port: 3306
            
node03: 同理类似

mysql>
ALTER USER 'root'@'localhost' IDENTIFIED BY '!@#qweASD69';
grant replication slave on *.*  to repl@'10.15.200.%' identified by '!@#qweASD69';
grant all on *.* to mha@'10.15.200.%' identified by '!@#qweASD69';
flush privileges;

node03上配置从服务器:
mysql>
CHANGE MASTER TO
MASTER_HOST='10.15.200.101',
MASTER_PORT=3306,
MASTER_LOG_FILE='bin-log.000002',
MASTER_LOG_POS=997,
MASTER_USER='repl',
MASTER_PASSWORD='!@#qweASD69';

mysql> show slave status\G;
             Slave_IO_Running: No
            Slave_SQL_Running: No

mysql> start slave;

mysql> show slave status\G;
*************************** 1. row ***************************
               Slave_IO_State: Waiting for master to send event
                  Master_Host: 10.15.200.101
                  Master_User: repl
                  Master_Port: 3306
                Connect_Retry: 60


# ping虚拟ip 无法ping通
~$ ping 10.15.200.118
PING 10.15.200.118 (10.15.200.118): 56 data bytes
Request timeout for icmp_seq 0

node01: 先在主库master上绑定VIP（只需手工绑定一次,后续脚本会自动切换）
[root@node01 ~]# ifconfig ens160:1 10.15.200.118/24      # 注意如果是ens32做对应的修改

[root@node01 ~]# ip addr
2: ens160: <BROADCAST,MULTICAST,UP,LOWER_UP>
    inet 10.15.200.118/24 brd 10.15.200.255 scope global secondary ens160:1
    
~$ ping 10.15.200.118 -c2
PING 10.15.200.118 (10.15.200.118): 56 data bytes
64 bytes from 10.15.200.118: icmp_seq=0 ttl=64 time=1.431 ms

# node05安装管理节点
yum install mha4mysql-node-0.58 mha4mysql-manager-0.58 -y
mkdir -p /etc/mha/scripts

1) 将: master_ip_failover  master_ip_online_change send_report
放于: /etc/mha/scripts 将给予执行权限

2) 将: app.conf 放于 /etc/mha/
3) 将: masterha_default.cnf 放于 /etc/masterha_default.cnf

node05赋予脚本执行权限:
[root@node05 ~]# chmod +x /etc/mha/scripts/*

# 如下两个文件 进行对应的替换
管理节点: NodeUtil.pm  /usr/share/perl5/vendor_perl/MHA/NodeUtil.pm
数据节点: SlaveUtil.pm /usr/share/perl5/vendor_perl/MHA/SlaveUtil.pm

# 检测 所有节点之间 SSH的 信任状态
[root@node05 ~]# masterha_check_ssh --conf=/etc/mha/app.cnf
Sun Sep 24 11:35:22 2023 - [info] All SSH connection tests passed successfully.

# 使用 masterha_check_repl 命令检查 mysql 主从是否正常
[root@node05 ~]# masterha_check_repl --conf=/etc/mha/app.cnf
MySQL Replication Health is OK.

启动MHA: 如下命令 会卡住不动
[root@node05 ~]# masterha_manager --conf=/etc/mha/app.cnf --remove_dead_master_conf --ignore_last_failover < /dev/null > /var/log/mha/app/manager.log 2>&1

通过日志检查MHA是否启动成功:
[root@node05 ~]# tailf /var/log/mha/app/manager.log

Thu Aug 24 15:40:13 2023 - [info] Set master ping interval 1 seconds.
Thu Aug 24 15:40:13 2023 - [info] Set secondary check script: /usr/bin/masterha_secondary_check -s node01 -s node02 -s node03
Thu Aug 24 15:40:13 2023 - [info] Starting ping health check on node01(10.15.200.101:3306)..
Thu Aug 24 15:40:13 2023 - [info] Ping(SELECT) succeeded, waiting until MySQL doesn't respond..

# 最后一行出现如下字样表明启动成功
Thu Aug 24 15:40:13 2023 - [info] Ping(SELECT) succeeded, waiting until MySQL doesn't respond..

检查MHA集群状态:
[root@node05 ~]# masterha_check_status --conf=/etc/mha/app.cnf
app (pid:32617) is running(0:PING_OK), master:node01

将node01的mysql服务停止:
[root@node01 ~]# systemctl stop mariadb.service

node05动态的查看日志:
[root@node05 ~]# tailf /var/log/mha/app/manager.log

----- Failover Report -----

app: MySQL Master failover node01(10.15.200.101:3306) to node02(10.15.200.102:3306) succeeded
Master node01(10.15.200.101:3306) is down!
Check MHA Manager logs at node05.example.cn:/var/log/mha/app/manager.log for details.

Started automated(non-interactive) failover.
Invalidated master IP address on node01(10.15.200.101:3306)
The latest slave node02(10.15.200.102:3306) has all relay logs for recovery.
Selected node02(10.15.200.102:3306) as a new master.
node02(10.15.200.102:3306): OK: Applying all logs succeeded.
node02(10.15.200.102:3306): OK: Activated master IP address.
node03(10.15.200.103:3306): This host has the latest relay log events.
Generating relay diff files from the latest slave succeeded.
node03(10.15.200.103:3306): OK: Applying all logs succeeded. Slave started, replicating from node02(10.15.200.102:3306)
node02(10.15.200.102:3306): Resetting slave info succeeded.
Master failover to node02(10.15.200.102:3306) completed successfully.

# 虚拟IP已经漂移到node02  node02由从的角色 提升为主的角色
[root@node02 ~]# ip a | grep 118
    inet 10.15.200.118/24 brd 10.15.200.255 scope global secondary ens160:1

# 此时发现 node03的主服务器由node01变为node02
[root@node03 ~]# mysql -uroot -p'!@#qweASD69' -e 'show slave status\G;' | egrep 'Master_Host|Running:'
                  Master_Host: 10.15.200.102
             Slave_IO_Running: Yes
            Slave_SQL_Running: Yes
                  
此时再次查看集群的状态 为失效的状态:
[root@node05 ~]# masterha_check_status --conf=/etc/mha/app.cnf
app is stopped(2:NOT_RUNNING).

[root@node05 ~]# cat /etc/mha/app.cnf    # 此文件中的[server1]段内容已经被删除

[root@node05 scripts]# cat /tmp/mha.log
MHA /etc/mha/app.cnf 主从切换成功
 master:node01 --> node02
 app: MySQL Master failover node01(10.15.200.101:3306) to node02(10.15.200.102:3306) succeeded
 当前从库:node03
 