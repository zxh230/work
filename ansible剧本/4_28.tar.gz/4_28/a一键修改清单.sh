echo "node01
node02
node03
node04
node05
ha01 mode=MASTER pri_id=120
ha02 mode=BACKUP pri_id=100" > /etc/asnible/inventory
