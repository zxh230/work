mysql_status=$(systemctl is-active mysql)
while ture
do
  if [ "$mysql_status" = "active"]; then
	exit 0
  else
	systemctl stop keepalived
  fi
  	sleep 1
done
