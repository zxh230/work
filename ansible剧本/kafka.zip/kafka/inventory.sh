echo "node04 kafka_id=11
node05 kafka_id=22
node06 kafka_id=33" > /etc/ansible/inventory
