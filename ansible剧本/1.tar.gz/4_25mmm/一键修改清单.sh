#!/bin/bash
echo "node01 my_id=101
node02 my_id=102
node03 my_id=103
[all:vars]
app_name=zxh" > /etc/ansible/inventory
