echo "node01
node02
node03
node04
node05
node06" > /etc/ansible/inventory
